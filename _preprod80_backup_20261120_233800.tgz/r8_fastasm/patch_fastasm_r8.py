#!/usr/bin/env python3
# patch_fastasm_r8.py -- fast assembly of the forms that remain in the staggered step (r8), applied to cosserat_kwc.edp.
#   phase field   : vphA, vphR by the plugin (k2dPhAsm) on a fixed pattern; vphD = A 1; vphB = A phik - R; lumped mass built once
#   phi means     : vph2, vgph (updatePhi2, called at every tangent refresh) and vDph by the plugin (k2dPhElem)
#   GND           : vCurlFp as two constant P0 -> P1 matrices built once
#   heat          : vTr as (rhoC/dt) M Tn + Bp01 Dsrc/dt with constant matrices
# -fastcheck N (default 50): every N-th call of each fast assembly is compared with the FreeFEM forms; a difference above -fastchecktol
# (default 1e-8) relative to the size of the terms stops the run with <out>_FASTCHECK.txt. The first call of a run is always checked; 0
# switches it off. Why 1e-8: plugin and forms evaluate 1 - phi at the quadrature points in a different order, and g'' = 2/(1-phi)^2 at
# phi_max = 1 - 1e-7 amplifies that round-off by up to 1e-7^-1 (relative 2e-9 at worst); a wrong formula or entry gives O(1).
# Needs the plugin of this version (kwc2d.cpp with k2dPhSetup, k2dPhAsm, k2dPhElem).  Usage: python3 patch_fastasm_r8.py [cosserat_kwc.edp]
import sys
fn = sys.argv[1] if len(sys.argv) > 1 else "cosserat_kwc.edp"
s = open(fn).read()
if "k2dPhAsm" in s:
    print("already patched:", fn); sys.exit(0)
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, ("fastasm patch target found %d times (expected %d)" % (n, cnt), a[:100]); s = s.replace(a, b)

# ---- set-up after the phi-mean forms: options, pattern, wrappers with the periodic comparison ----
rep('''func int updatePhi2() { ph2m = vph2(0, Ph); ph2m = ph2m ./ areas; gm = vgph(0, Ph); gm = gm ./ areas; return 0; }
''', '''// ---- r8 fast assembly (patch_fastasm_r8.py): plugin k2dPhAsm / k2dPhElem and constant operators, compared with the forms every -fastcheck calls ----
int fastCheck = atoi(arg("-fastcheck", "50")); real fastTol = atof(arg("-fastchecktol", "1e-8"));
int nFastPh = 0, nFastEl = 0, nFastLin = 0, nFastChk = 0; real fastDev = 0;
matrix Aph; real[int] phV(1), phOne(Vh1.ndof), phP(9); phOne = 1.;
real[int,int] phF(Vh1.ndof, 4), phE(nt, 2), phF3(Vh1.ndof, 3), phO(nt, 3);
{ varf vpat(p, q) = int2d(Th)(p*q + dx(p)*dx(q) + dy(p)*dy(q)); Aph = vpat(Vh1, Vh1);
  int[int] I0(1), J0(1); real[int] C0(1); [I0, J0, C0] = Aph; phV.resize(I0.n);
  int[int,int] Cn(nt, 3); real[int,int] XY(nt, 6);
  for (int k = 0; k < nt; k++) for (int a = 0; a < 3; a++) { Cn(k, a) = Vh1(k, a); XY(k, 2*a) = Th[k][a].x; XY(k, 2*a+1) = Th[k][a].y; }
  real miss = k2dPhSetup(Cn, XY, I0, J0);
  if (miss != 0) { cout << "fast assembly: the phase pattern misses " << miss << " element entries" << endl; exit(5); } }
func int fastStop(string what, real dev) {
  if (isRoot()) { ofstream fs(out + "_FASTCHECK.txt"); fs << "fast assembly of " << what << " differs from the FreeFEM forms by " << dev << " (relative; tolerance " << fastTol << ")" << endl; }
  cout << "FASTCHECK: " << what << " differs from the forms by " << dev << endl; exit(6); return 0; }
func bool fastDue(int cnt) { return fastCheck > 0 && (cnt == 1 || cnt % fastCheck == 0); }
// regime triggers of the phase assembly: the first call in which the Arrhenius floor is reached anywhere, and the first call in which a node
// sits on a bound of phi, are always checked (state-dependent branches of the formulas that a 1-in-N sample could miss)
real TfloorArr = 1./(1./T0 - log(1./phiArrMin)*Rgas/Qphi); int seenFloor = 0, seenBound = 0;
func bool phRegime() {
  bool due = false;
  if (!seenFloor && gmaxS(T[].max) >= TfloorArr) { seenFloor = 1; due = true; }
  if (!seenBound) { real pm = gmaxS(phi[].max), pn0 = -gmaxS(-phi[].min); if (pm >= phimax - 1e-12 || pn0 <= 1e-12) { seenBound = 1; due = true; } }
  return due;
}
// difference of two local vectors relative to the reference, or to the size sc of the terms that cancel in it (all ranks together)
func real relDiff(real[int] & a, real[int] & bb) { real[int] d = a - bb; return gmaxS(d.linfty)/max(gmaxS(bb.linfty), 1e-300); }
// row by row: |a_i - b_i| / sc_i, sc_i = size of the terms of row i (the global max norm would hide an error in a row with small entries
// behind rows with g'' ~ 1e14 near phi = 1, or behind cancelling terms)
func real relRow(real[int] & a, real[int] & bb, real[int] & sc) {   // rows below 1e-13 of the largest row scale are measured against that floor
  real[int] d = a - bb; d = abs(d); real[int] t = sc; t += max(1e-13*gmaxS(sc.max), 1e-300); d = d ./ t; return gmaxS(d.max); }
func matrix absMat(matrix & A, int nr, int nc) { int[int] I1(1), J1(1); real[int] C1(1); [I1, J1, C1] = A; C1 = abs(C1); matrix B = [I1, J1, C1]; B.resize(nr, nc); return B; }
// element means of phi^2 and g(phi), and the phase dissipation density eta_phi(T)(phi - phin)^2/dt (plugin; forms vph2, vgph, vDph)
func int phElem(real eta) {
  phF3(:, 0) = phi[]; phF3(:, 1) = phin[]; phF3(:, 2) = T[];
  phP = [eta, dt, f0, sK, aK, T0, Qphi/Rgas, phiArrMin, 0.5*chi*mu*b*b];
  k2dPhElem(phF3, phP, phO); nFastEl++;
  if (fastDue(nFastEl)) {
    real etaPhi = eta; varf vDphC(un, w) = int2d(Th)(etaPhi*phArr*(phi - phin)^2/dt*w);
    real[int] a2 = vph2(0, Ph), ag = vgph(0, Ph), ad = vDphC(0, Ph); a2 = a2 ./ areas; ag = ag ./ areas; ad = ad ./ areas;
    real[int] b2 = phO(:, 0), bg = phO(:, 1), bd = phO(:, 2);
    real[int] s2 = abs(a2), sg = abs(ag); real dv = max(relRow(b2, a2, s2), relRow(bg, ag, sg));
    dv = max(dv, relDiff(bd, ad));   // dissipation: against its largest value ((phi - phin)^2 loses digits where phi barely changes)
    nFastChk++; fastDev = max(fastDev, dv); if (!(dv <= fastTol)) fastStop("the phi element means / phase dissipation", dv);
  }
  return 0;
}
func int updatePhi2() { phElem(0.); ph2m = phO(:, 0); gm = phO(:, 1); return 0; }
''')

# ---- GND: constant curl operators ----
rep('''varf vCurlFp(un, w) = int2d(Th)(-(fpA*dx(w) - fpB*dy(w))) + int1d(Th, 1, 2, 3, 4)((fpA*N.x - fpB*N.y)*w);
''', '''varf vCurlFp(un, w) = int2d(Th)(-(fpA*dx(w) - fpB*dy(w))) + int1d(Th, 1, 2, 3, 4)((fpA*N.x - fpB*N.y)*w);
// r8: the same form as two constant P0 -> P1 operators, c = CurlA fpA + CurlB fpB
varf vCurlA(un, w) = int2d(Th)(-un*dx(w)) + int1d(Th, 1, 2, 3, 4)(un*N.x*w);
varf vCurlB(un, w) = int2d(Th)(un*dy(w)) - int1d(Th, 1, 2, 3, 4)(un*N.y*w);
matrix CurlA = vCurlA(Ph, Vh1), CurlB = vCurlB(Ph, Vh1), CurlAbs;
// CurlAbs: sum of the entrywise absolute values of the area and boundary parts taken apart (size of the cancelling terms, for the check;
// at a corner node the two parts cancel inside one entry)
{ varf vA2(un, w) = int2d(Th)(-un*dx(w)); varf vA1(un, w) = int1d(Th, 1, 2, 3, 4)(un*N.x*w);
  varf vB2(un, w) = int2d(Th)(un*dy(w)); varf vB1(un, w) = int1d(Th, 1, 2, 3, 4)(un*N.y*w);
  matrix P1m = vA2(Ph, Vh1), P2m = vA1(Ph, Vh1), P3m = vB2(Ph, Vh1), P4m = vB1(Ph, Vh1);
  CurlAbs = absMat(P1m, Vh1.ndof, nt); matrix Q2 = absMat(P2m, Vh1.ndof, nt), Q3 = absMat(P3m, Vh1.ndof, nt), Q4 = absMat(P4m, Vh1.ndof, nt);
  CurlAbs = CurlAbs + Q2; CurlAbs = CurlAbs + Q3; CurlAbs = CurlAbs + Q4; }
func real[int] curlFast(real[int] & a, real[int] & bb) {
  real[int] c = CurlA*a; real[int] c2 = CurlB*bb; c += c2; nFastLin++;
  if (fastDue(nFastLin)) { fpA[] = a; fpB[] = bb; real[int] cf = vCurlFp(0, Vh1); real[int] ab = abs(a), bab = abs(bb); ab += bab; real[int] ta = CurlAbs*ab; real dv = relRow(c, cf, ta); nFastChk++; fastDev = max(fastDev, dv); if (!(dv <= fastTol)) fastStop("the GND curl", dv); }
  return c;
}
''')
rep('''  fpA[] = fp12; fpB[] = fp11; c1[] = vCurlFp(0, Vh1); syncP1(c1[]); c1[] = c1[] ./ lumpS;
  fpA[] = fp22; fpB[] = fp21; c2[] = vCurlFp(0, Vh1); syncP1(c2[]); c2[] = c2[] ./ lumpS;''',
'''  c1[] = curlFast(fp12, fp11); syncP1(c1[]); c1[] = c1[] ./ lumpS;   // r8: = vCurlFp with fpA = fp12, fpB = fp11
  c2[] = curlFast(fp22, fp21); syncP1(c2[]); c2[] = c2[] ./ lumpS;''')

# ---- heat right-hand side: constant mass matrix and the P0 -> P1 operator ----
rep('''varf vTr(T, xi) = int2d(Th)(rhoC/dt*Tn*xi + Dsrc/dt*xi);
''', '''varf vTr(T, xi) = int2d(Th)(rhoC/dt*Tn*xi + Dsrc/dt*xi);
varf vMT(T, xi) = int2d(Th)(T*xi);
matrix MTh = vMT(Vh1, Vh1);   // r8: heat right-hand side (rhoC/dt) M Tn + Bp01 Dsrc/dt
''')
rep('''  real[int] rT = vTr(0, Vh1);
''', '''  real[int] rT = MTh*Tn[]; rT *= rhoC/dt; { real[int] rs = Bp01*Dsrc[]; rs *= 1./dt; rT += rs; }   // r8: = vTr
  nFastLin++; if (fastDue(nFastLin)) { real[int] rf = vTr(0, Vh1); real[int] sc = MTh*Tn[]; sc = abs(sc); sc *= rhoC/dt; { real[int] ad = abs(Dsrc[]); real[int] t2 = Bp01*ad; t2 *= 1./dt; sc += t2; } real dv = relRow(rT, rf, sc); nFastChk++; fastDev = max(fastDev, dv); if (!(dv <= fastTol)) fastStop("the heat right-hand side", dv); }
''')

# ---- phase field: plugin assembly inside the active-set iteration ----
rep('''        real[int] rk = vphR(0, Vh1), dk = vphD(0, Vh1); real[int] pk = phi[];''',
'''        // r8: A (= vphA at phik) and R (= vphR at phi; phi = phik here) by the plugin; D = A 1 (= vphD: the stiffness rows sum to zero),
        // b = A phik - R (= vphB); compared with the forms every -fastcheck calls
        real[int] rk(Vh1.ndof);
        phF(:, 0) = phi[]; phF(:, 1) = phik[]; phF(:, 2) = phin[]; phF(:, 3) = T[]; phE(:, 0) = Nd[]; phE(:, 1) = rr[];
        phP = [etaPhi, dt, f0, sK, aK, T0, Qphi/Rgas, phiArrMin, 0.5*chi*mu*b*b];
        k2dPhAsm(phF, phE, phP, phV, rk); Aph.coef = phV; nFastPh++;
        bool phReg = phRegime();
        if (fastDue(nFastPh) || (fastCheck > 0 && phReg)) {
          matrix Af = vphA(Vh1, Vh1); real[int] rf = vphR(0, Vh1), df = vphD(0, Vh1), bf = vphB(0, Vh1);
          real[int] zz(Vh1.ndof); for (int i = 0; i < Vh1.ndof; i++) zz[i] = 1. + 0.5*sin(1.7*i + 0.3);
          matrix Aab = absMat(Af, Vh1.ndof, Vh1.ndof);
          real[int] y1 = Af*zz, y2 = Aph*zz, s1 = Aab*zz; real dv = relRow(y2, y1, s1);                                     // matrix, row by row
          real[int] ap = abs(phik[]); real[int] sR = Aab*ap; real[int] t1 = abs(bf); sR += t1; dv = max(dv, relRow(rk, rf, sR));   // R = A phik - b
          real[int] dd = Aph*phOne; real[int] s0 = Aab*phOne; dv = max(dv, relRow(dd, df, s0));                             // D = A 1
          real[int] bb2 = Aph*phik[]; bb2 -= rk; real[int] sB = Aab*ap; t1 = abs(rf); sB += t1; dv = max(dv, relRow(bb2, bf, sB));   // b = A phik - R
          nFastChk++; fastDev = max(fastDev, dv); if (!(dv <= fastTol)) fastStop("the phase-field matrix / residual", dv);
        }
        real[int] dk = Aph*phOne; real[int] pk = phi[];''')
rep('''        matrix Aphl = vphA(Vh1, Vh1); real[int] bph = vphB(0, Vh1); matrix Lm = vphL(Vh1, Vh1);''',
    '''        matrix Aphl = Aph; real[int] bph = Aph*phik[]; bph -= rk; matrix Lm = phLm;   // r8''')
rep('''    varf vphL(phi, xi) = int2d(Th, qft=qf1pTlump)(phi*xi);
''', '''    varf vphL(phi, xi) = int2d(Th, qft=qf1pTlump)(phi*xi);
    if (phLm.n != Vh1.ndof) phLm = vphL(Vh1, Vh1);   // r8: constant, built once
''')
rep('''      varf vDph(un, w) = int2d(Th)(etaPhi*phArr*(phi - phin)^2/dt*w);
      real[int] dq = vDph(0, Ph); dq = dq ./ areas; Dloc += dq;''',
'''      phElem(etaPhi); real[int] dq = phO(:, 2); Dloc += dq;   // r8: = vDph / areas''')
rep('''for (int n = nstart + 1; n <= ntot; n++) {
''', '''matrix phLm;   // r8: lumped phase mass, built at the first phase step
for (int n = nstart + 1; n <= ntot; n++) {
''')
# ---- end-of-run summary ----
_d = 'cout << "done. wall time '
assert s.count(_d) == 1
_j = s.rfind('\n', 0, s.index(_d)) + 1
s = s[:_j] + 'real fastDevG = gmaxS(fastDev);   // r8d: reduced by every rank (a collective inside cout runs on rank 0 only in MPI)\ncout << "fast assembly (r8): phase " << nFastPh << ", element means " << nFastEl << ", linear operators " << nFastLin << " calls; " << nFastChk << " compared with the forms (-fastcheck " << fastCheck << "), largest relative difference " << fastDevG << endl;\n' + s[_j:]
open(fn, "w").write(s)
print("patched", fn)

# ---------------------------------------------------------------- r8b: phase-field linear solve by projected CG ----------------------
# The eliminated active-set system (free block of A + lumped rows on the active nodes) is SPD; CG with the Jacobi preconditioner on it is
# the projected PCG with the constraint preconditioner [diag(A) E^T; E 0] (Gould, Hribar, Nocedal 2001) for these node-wise bounds (same
# iterates).  -phsolver cg (default) | direct.  MPI: -petscph (PETSCPH), default CG + Jacobi.  A phase step that does not converge with CG
# is repeated once from phi_n with the previous solver (serial: sparse direct; MPI: -petscp1), counted, then the usual stop applies.
s = open(fn).read()
def rep2(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, ("phcg patch target found %d times (expected %d)" % (n, cnt), a[:100]); s = s.replace(a, b)
rep2('''int fastCheck = atoi(arg("-fastcheck", "50"));''', '''int phCG = (arg("-phsolver", "cg") == "cg") ? 1 : 0; int nPhFall = 0;   // r8b: phase-field linear solve by projected CG (CG + Jacobi on the eliminated system)
real[int] phDinv(Vh1.ndof);
func real[int] PJph(real[int] & bb) { real[int] x = bb .* phDinv; return x; }
int nPhCGfail = 0, nPhCGit = 0;
// preconditioned CG (Jacobi) on the SPD eliminated system; stops on |b - A x|_inf <= 1e-13 |b|_inf; returns the iterations (0: the start
// already satisfies it), -1 if not converged in 2000 iterations or p'Ap <= 0 (then the caller solves directly)
func int phPCG(matrix & A, real[int] & x, real[int] & bb) {
  real[int] r = A*x; r -= bb; r *= -1.; real nb = max(bb.linfty, 1e-300);
  if (r.linfty <= 1e-13*nb) return 0;
  real[int] z = r .* phDinv; real[int] p = z; real rz = r'*z;
  for (int it = 1; it <= 2000; it++) {
    real[int] q = A*p; real pq = p'*q; if (!(pq > 0)) return -1;
    real al = rz/pq; real[int] t = p; t *= al; x += t; t = q; t *= al; r -= t;
    if (r.linfty <= 1e-13*nb) return it;
    z = r .* phDinv; real rz2 = r'*z; real be = rz2/rz; rz = rz2; p *= be; p += z;
  }
  return -1;
}
int fastCheck = atoi(arg("-fastcheck", "50"));''')
rep2('''    for (int kn = 0; kn < phiMaxIt; kn++) {
      phiNit = kn + 1;''', '''    int phCGnow = phCG;
    for (int phPass = 0; phPass < 2; phPass++) {   // r8b: a step that fails with CG is repeated once with the previous solver
    if (phPass > 0) { phi = phin; phik = phi; phiConv = 0; phiNit = 0; phiKktV = 0; phCGnow = 0; nPhFall++;
      cout << "step " << n << ": phase-field step not converged with CG, repeated with the direct/ASM solver" << endl; }
    for (int kn = 0; kn < phiMaxIt; kn++) {
      phiNit = kn + 1;''')
rep2('''        set(Am, solver = sparsesolver);
        phi[] = Am^-1*bph;
''', '''        if (phCGnow) { phDinv = Am.diag; phDinv = phOne ./ phDinv; real[int] x0 = phi[];
          int itcg = phPCG(Am, x0, bph);
          if (itcg >= 0) { phi[] = x0; nPhCGit += itcg; } else { nPhCGfail++; set(Am, solver = sparsesolver); x0 = Am^-1*bph; phi[] = x0; } }
        else {
        set(Am, solver = sparsesolver);
        phi[] = Am^-1*bph;
        }
''')
rep2('''        break;
      }
    }
    if (!phiConv) {   // phase-field Newton did not reach''', '''        break;
      }
    }
    if (phiConv || !phCGnow) break;
    }
    if (!phiConv) {   // phase-field Newton did not reach''')
_d = 'cout << "fast assembly (r8): phase "'
assert s.count(_d) == 1
_j = s.rfind('\n', 0, s.index(_d)) + 1
s = s[:_j] + 'cout << "phase-field linear solve (r8b): " << (phCG ? "projected CG (CG + Jacobi on the eliminated system)" : "direct") << ", CG iterations " << nPhCGit << ", CG solves redone directly " << nPhCGfail << ", steps repeated with the previous solver " << nPhFall << endl;\n' + s[_j:]
open(fn, "w").write(s)
print("patched (r8b phase CG)", fn)
