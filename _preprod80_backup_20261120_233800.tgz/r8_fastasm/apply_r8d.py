#!/usr/bin/env python3
# apply_r8d.py -- fix: the r8 end-of-run line evaluated gmaxS (an MPI all-reduce) inside a cout statement. The MPI generator restricts
# every cout to rank 0, so only rank 0 called the all-reduce: it paired with the other ranks' next all-reduce and the run hung at its end
# (after all steps and the relaxed checkpoint were written). The value is now reduced first, by every rank.  Usage: python3 apply_r8d.py [repo]
import os, sys, shutil, re
root = sys.argv[1] if len(sys.argv) > 1 else "."; f = os.path.join(root, "cosserat_kwc.edp"); s = open(f).read()
old = re.compile(r'(\ncout << "fast assembly \(r8[^\n]*?largest relative difference " << )gmaxS\(fastDev\)( << endl;)')
m = old.findall(s)
if len(m) != 1: print("NOT APPLIED: the r8 summary line with gmaxS(fastDev) was found %d times" % len(m)); sys.exit(1)
s = old.sub(lambda mm: "\nreal fastDevG = gmaxS(fastDev);   // r8d: reduced by every rank (a collective inside cout runs on rank 0 only in MPI)" + mm.group(1) + "fastDevG" + mm.group(2), s)
shutil.copy2(f, f + ".pre_r8d"); open(f, "w").write(s); print("applied (backup cosserat_kwc.edp.pre_r8d). Next: bash plugin/build_plugin.sh")
