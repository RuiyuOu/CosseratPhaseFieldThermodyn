// ---------------- phase field (fast assembly, r8): the forms vphA, vphR, vph2, vgph, vDph of the solver on a fixed pattern ----------------
// Same 7-point rule as FreeFEM's int2d default (qf5pT). P1 phi, phik, phin, T; P0 N, rho_S.
namespace kph {
  int nel = 0; long nnz = 0, ndof = 0;
  std::vector<int> conn, pos; std::vector<double> area, gx, gy;
  double L[7][3], W[7];
  void rule() {
    const double s = sqrt(15.), a1 = (6 - s)/21, b1 = (9 + 2*s)/21, a2 = (6 + s)/21, b2 = (9 - 2*s)/21;
    const double P[7][3] = {{1./3, 1./3, 1./3}, {a1, a1, b1}, {a1, b1, a1}, {b1, a1, a1}, {a2, a2, b2}, {a2, b2, a2}, {b2, a2, a2}};
    for (int q = 0; q < 7; q++) { for (int i = 0; i < 3; i++) L[q][i] = P[q][i]; W[q] = (q == 0) ? 9./40 : (q < 4 ? (155 - s)/1200 : (155 + s)/1200); }
  }
}
// set-up: C (nt x 3 P1 dofs), XY (nt x 6 vertex coordinates), I, J = entry order of the phase matrix ([I, J, C] = A). Returns the entries missed (0).
double k2dPhSetup(KNM<long> *const &C, KNM<double> *const &XY, KN<long> *const &I, KN<long> *const &J) {
  using namespace kph; rule();
  nel = C->N(); nnz = I->N(); conn.resize((size_t)nel*3); area.resize(nel); gx.resize((size_t)nel*3); gy.resize((size_t)nel*3); pos.resize((size_t)nel*9);
  ndof = 0; for (long e = 0; e < nnz; e++) ndof = std::max(ndof, std::max((*I)[e], (*J)[e]) + 1);
  for (int k = 0; k < nel; k++) ndof = std::max(ndof, std::max((*C)(k, 0), std::max((*C)(k, 1), (*C)(k, 2))) + 1);
  std::vector<std::pair<long,long> > key(nnz); for (long e = 0; e < nnz; e++) key[e] = std::make_pair((*I)[e]*ndof + (*J)[e], e);
  std::sort(key.begin(), key.end());
  long miss = 0;
  for (int k = 0; k < nel; k++) {
    for (int a = 0; a < 3; a++) conn[k*3 + a] = (int)(*C)(k, a);
    const double x0 = (*XY)(k,0), y0 = (*XY)(k,1), x1 = (*XY)(k,2), y1 = (*XY)(k,3), x2 = (*XY)(k,4), y2 = (*XY)(k,5);
    const double d = (x1 - x0)*(y2 - y0) - (x2 - x0)*(y1 - y0); area[k] = 0.5*fabs(d);
    gx[k*3+0] = (y1 - y2)/d; gx[k*3+1] = (y2 - y0)/d; gx[k*3+2] = (y0 - y1)/d;
    gy[k*3+0] = (x2 - x1)/d; gy[k*3+1] = (x0 - x2)/d; gy[k*3+2] = (x1 - x0)/d;
    for (int a = 0; a < 3; a++) for (int b = 0; b < 3; b++) {
      const long kk = (long)conn[k*3+a]*ndof + conn[k*3+b];
      auto it = std::lower_bound(key.begin(), key.end(), std::make_pair(kk, -1L));
      if (it == key.end() || it->first != kk) { miss++; pos[(size_t)k*9 + a*3 + b] = 0; } else pos[(size_t)k*9 + a*3 + b] = (int)it->second;
    }
  }
  return (double)miss;
}
// matrix values V (vphA, linearised at phik) and residual R (vphR, at phi).  F (ndof x 4): phi, phik, phin, T.  E (nt x 2): N, rho_S.
// P: etaPhi, dt, f0, sK, aK, T0, Q/R, Arrhenius floor, c_s = chi mu b^2/2.
double k2dPhAsm(KNM<double> *const &F, KNM<double> *const &E, KN<double> *const &P, KN<double> *const &V, KN<double> *const &R) {
  using namespace kph;
  const KNM<double> &f = *F; const KNM<double> &el = *E; const KN<double> &p = *P;
  const double eta = p[0], dt = p[1], f0 = p[2], sK = p[3], aK = p[4], T0 = p[5], QR = p[6], amin = p[7], cs = p[8], kK = f0*aK*aK;
  KN<double> &v = *V, &r = *R; ffassert(nel > 0 && v.N() == nnz && r.N() == ndof && el.N() == nel);
  for (long e = 0; e < nnz; e++) v[e] = 0.; for (long i = 0; i < ndof; i++) r[i] = 0.;
  for (int k = 0; k < nel; k++) {
    const int *c = &conn[(size_t)k*3]; const double A = area[k], N = el(k, 0), rho = el(k, 1);
    double ph[3], pk[3], pn[3], T[3]; for (int a = 0; a < 3; a++) { ph[a] = f(c[a], 0); pk[a] = f(c[a], 1); pn[a] = f(c[a], 2); T[a] = f(c[a], 3); }
    double Me[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0}, re[3] = {0, 0, 0};
    for (int q = 0; q < 7; q++) {
      const double *l = L[q]; double phq = 0, pkq = 0, pnq = 0, Tq = 0;
      for (int a = 0; a < 3; a++) { phq += l[a]*ph[a]; pkq += l[a]*pk[a]; pnq += l[a]*pn[a]; Tq += l[a]*T[a]; }
      const double arr = std::max(exp(QR*(1./Tq - 1./T0)), amin)*eta/dt;
      const double om = 1. - pkq, cq = arr + f0 + f0*sK*N*2./(om*om);
      const double fq = arr*(phq - pnq) + f0*phq + f0*sK*N*2.*phq/(1. - phq) - (f0 - cs*rho);
      const double w = W[q]*A;
      for (int a = 0; a < 3; a++) { re[a] += w*fq*l[a]; for (int b = 0; b < 3; b++) Me[a*3 + b] += w*cq*l[a]*l[b]; }
    }
    const double *Gx = &gx[(size_t)k*3], *Gy = &gy[(size_t)k*3];
    for (int a = 0; a < 3; a++) {
      double kr = 0;
      for (int b = 0; b < 3; b++) { const double ke = kK*A*(Gx[a]*Gx[b] + Gy[a]*Gy[b]); v[pos[(size_t)k*9 + a*3 + b]] += Me[a*3 + b] + ke; kr += ke*ph[b]; }
      r[c[a]] += re[a] + kr;
    }
  }
  return 0;
}
// element integrals divided by the area (vph2, vgph, vDph of the solver): O (nt x 3) = mean phi^2, mean g(phi), mean eta_phi(T)(phi - phin)^2/dt.
// F (ndof x 3): phi, phin, T.  P as for k2dPhAsm (etaPhi, dt, ..., Q/R, floor).
double k2dPhElem(KNM<double> *const &F, KN<double> *const &P, KNM<double> *const &O) {
  using namespace kph;
  const KNM<double> &f = *F; const KN<double> &p = *P; KNM<double> &o = *O; ffassert(nel > 0 && o.N() == nel && o.M() >= 3);
  const double eta = p[0], dt = p[1], T0 = p[5], QR = p[6], amin = p[7];
  for (int k = 0; k < nel; k++) {
    const int *c = &conn[(size_t)k*3]; double s2 = 0, sg = 0, sd = 0;
    for (int q = 0; q < 7; q++) {
      double phq = 0, pnq = 0, Tq = 0; for (int a = 0; a < 3; a++) { phq += L[q][a]*f(c[a], 0); pnq += L[q][a]*f(c[a], 1); Tq += L[q][a]*f(c[a], 2); }
      const double arr = std::max(exp(QR*(1./Tq - 1./T0)), amin), dp = phq - pnq;
      s2 += W[q]*phq*phq; sg += W[q]*(-2.*(phq + log(1. - phq))); sd += W[q]*eta*arr*dp*dp/dt;
    }
    o(k, 0) = s2; o(k, 1) = sg; o(k, 2) = sd;   // the weights sum to 1: these are the element means
  }
  return 0;
}
