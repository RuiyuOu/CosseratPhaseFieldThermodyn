#!/usr/bin/env python3
# apply_r8c.py -- one switch for all fast assembly, on by default (after apply_r8.py).
#   solver : -fastasm 1 (default) | 0.  0 = every staggered field by the FreeFEM forms again (phase: vphA, vphR, vphD, vphB each iteration;
#            vph2, vgph, vDph, vCurlFp, vTr), exactly the 7.1 path, for anyone who changes a form and has not changed the plugin kernels.
#   v2     : -asm default 1 (mechanics tangent by the plugin) instead of 0, so a solver started by hand is fast too.
#   run.sh : FASTASM=1 (default) passes -asm 1; FASTASM=0 passes -asm 0 -fastasm 0 (both slow paths).
# Every edit point is checked first; nothing is written if one is missing. Backups <file>.pre_r8c.  Usage: python3 apply_r8c.py [repo_dir]
import os, sys, shutil
root = sys.argv[1] if len(sys.argv) > 1 else "."
P = lambda f: os.path.join(root, f)
names = ["cosserat_kwc.edp", "v2/make_v2.py", "run.sh"]
txt = {f: open(P(f)).read() for f in names}; new = dict(txt); bad = []
def rep(f, a, b):
    if new[f].count(a) != 1: bad.append("%s: edit point found %d times: %s" % (f, new[f].count(a), a.strip()[:90])); return
    new[f] = new[f].replace(a, b)
e = "cosserat_kwc.edp"
if "-fastasm" in txt[e]: bad.append("cosserat_kwc.edp already has -fastasm")
if "k2dPhAsm" not in txt[e]: bad.append("cosserat_kwc.edp: apply_r8.py first")
rep(e, 'int fastCheck = atoi(arg("-fastcheck", "50"));',
       'int fastAsm = atoi(arg("-fastasm", "1"));   // r8c: 1 = fast assembly of the staggered fields (plugin, constant operators); 0 = FreeFEM forms (7.1 path)\n'
       'int fastCheck = atoi(arg("-fastcheck", "50"));')
# element means / phase dissipation
rep(e, '''func int phElem(real eta) {
  phF3(:, 0) = phi[];''', '''func int phElem(real eta) {
  if (!fastAsm) {   // r8c: forms
    real etaPhi = eta; varf vDphS(un, w) = int2d(Th)(etaPhi*phArr*(phi - phin)^2/dt*w);
    real[int] a2 = vph2(0, Ph), ag = vgph(0, Ph), ad = vDphS(0, Ph); a2 = a2 ./ areas; ag = ag ./ areas; ad = ad ./ areas;
    phO(:, 0) = a2; phO(:, 1) = ag; phO(:, 2) = ad; return 0; }
  phF3(:, 0) = phi[];''')
# GND curl
rep(e, '''func real[int] curlFast(real[int] & a, real[int] & bb) {
  real[int] c = CurlA*a;''', '''func real[int] curlFast(real[int] & a, real[int] & bb) {
  if (!fastAsm) { fpA[] = a; fpB[] = bb; real[int] cs = vCurlFp(0, Vh1); return cs; }   // r8c: form
  real[int] c = CurlA*a;''')
# heat right-hand side
rep(e, '''  real[int] rT = MTh*Tn[]; rT *= rhoC/dt; { real[int] rs = Bp01*Dsrc[]; rs *= 1./dt; rT += rs; }   // r8: = vTr
  nFastLin++; if (fastDue(nFastLin))''', '''  real[int] rT(Vh1.ndof);
  if (!fastAsm) rT = vTr(0, Vh1);   // r8c: form
  else { rT = MTh*Tn[]; rT *= rhoC/dt; { real[int] rs = Bp01*Dsrc[]; rs *= 1./dt; rT += rs; }   // r8: = vTr
  nFastLin++; } if (fastAsm && fastDue(nFastLin))''')
# phase field: the four forms each iteration when -fastasm 0
rep(e, '''        real[int] rk(Vh1.ndof);
        phF(:, 0) = phi[];''', '''        real[int] rk(Vh1.ndof);
        if (!fastAsm) { matrix Afm = vphA(Vh1, Vh1); Aph = Afm; rk = vphR(0, Vh1); }   // r8c: forms (D and b below by vphD, vphB)
        else {
        phF(:, 0) = phi[];''')
rep(e, '''          nFastChk++; fastDev = max(fastDev, dv); if (!(dv <= fastTol)) fastStop("the phase-field matrix / residual", dv);
        }
''', '''          nFastChk++; fastDev = max(fastDev, dv); if (!(dv <= fastTol)) fastStop("the phase-field matrix / residual", dv);
        }
        }
''')
rep(e, '''        real[int] dk = Aph*phOne; real[int] pk = phi[];''',
       '''        real[int] dk(Vh1.ndof); if (fastAsm) dk = Aph*phOne; else dk = vphD(0, Vh1);   // r8c
        real[int] pk = phi[];''')
rep(e, '''        matrix Aphl = Aph; real[int] bph = Aph*phik[]; bph -= rk; matrix Lm = phLm;   // r8''',
       '''        matrix Aphl = Aph; real[int] bph(Vh1.ndof); if (fastAsm) { bph = Aph*phik[]; bph -= rk; } else bph = vphB(0, Vh1); matrix Lm = phLm;   // r8, r8c''')
rep(e, 'cout << "fast assembly (r8): phase "', 'cout << "fast assembly (r8, -fastasm " << fastAsm << "): phase "')
# v2: mechanics tangent by the plugin by default
rep("v2/make_v2.py", 'int asmFast = atoi(arg("-asm", "0"));', 'int asmFast = atoi(arg("-asm", "1"));')
# run.sh: one switch
rep("run.sh", '[ "$FASTASM" = 1 ] && XARGS="-asm 1"',
    'if [ "$FASTASM" = 1 ]; then XARGS="-asm 1"; else XARGS="-asm 0 -fastasm 0"; fi   # FASTASM=0: mechanics tangent and staggered fields by the FreeFEM forms')
if bad:
    print("NOT APPLIED (nothing written):"); [print("  -", b) for b in bad]; sys.exit(1)
for f in names:
    if new[f] != txt[f]: shutil.copy2(P(f), P(f) + ".pre_r8c"); open(P(f), "w").write(new[f])
print("applied to", root, "(backups *.pre_r8c). Next: bash plugin/build_plugin.sh")
