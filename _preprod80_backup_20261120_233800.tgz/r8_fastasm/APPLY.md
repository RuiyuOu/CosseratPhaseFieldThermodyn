# Fast assembly of the staggered fields + projected-CG phase-field solve (r8)

Your tree is at 7.4; this was built and tested on 7.1. Do NOT copy files over your tree. Apply in place:

    cd /work/users/r/y/ryo7/KWCProd/CosseratPhaseFieldThermodyn
    python3 /path/to/r8_fastasm/apply_r8.py .      # checks every edit point first; writes nothing if one is missing; backups *.pre_r8
    bash plugin/build_plugin.sh                     # rebuilds kwc2d.so, regenerates cosserat_kwc_v2.edp and cosserat_kwc_v2_mpi.edp

It edits four files: cosserat_kwc.edp (via patch_fastasm_r8.py), mpi/make_mpi.py, run.sh (passes PETSCPH), plugin/kwc2d.cpp (phase
kernels). If 7.3/7.4 changed one of the edit points, it stops and names the file; send me that file and I will rebase the patch.
Then the switch (r8c; after apply_r8.py):

    python3 /path/to/r8_fastasm/apply_r8c.py .  &&  bash plugin/build_plugin.sh

-fastasm 1 (default) | 0 for the staggered fields; the v2 default of -asm becomes 1 (mechanics tangent by the plugin); FASTASM=0 in
run.sh now passes "-asm 0 -fastasm 0", i.e. every matrix and vector by the FreeFEM forms (the 7.1 path), for anyone changing a form.
Docs: DOCS_r8.md (sections for the production notes). Bump VERSION / README yourselves.

New options: -fastcheck N (50; 0 off), -fastchecktol (1e-8), -phsolver cg|direct (cg), MPI -petscph / env PETSCPH
(default "-ksp_type cg -ksp_rtol 1e-13 -ksp_max_it 2000 -pc_type jacobi"). Independent of -kwctan (2 or 3).
End of each .out: "phase-field linear solve (r8b): ... CG iterations N, CG solves redone directly 0, steps repeated ... 0" and
"fast assembly (r8): ... largest relative difference ~1e-12".
