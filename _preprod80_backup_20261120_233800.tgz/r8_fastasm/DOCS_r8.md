# Text for the production notes (version with fast assembly + projected CG)

Insert after Section 6.10; renumber to fit your 7.4 notes. Also add the MPI-options row
`| -petscph | CG + Jacobi | phi (projected CG) |` and the safeguard rows `-fastcheck 50, -fastchecktol 1e-8` and "phase CG fallback".

## 6.12 Fast assembly of the staggered fields (`patch_fastasm_r8.py`, version 7.2)

The forms that the step still assembled with FreeFEM are replaced by the plugin or by constant operators; the matrices and vectors are
the same to round-off (coarse run, 10 + 10 steps: every log column identical except `locres` at 10⁻¹⁵, the same Newton iterations).

| Form | Replaced by | When |
|---|---|---|
| `vphA`, `vphR` (phase matrix at φₖ, residual) | `k2dPhAsm`: one element loop, 7-point rule `qf5pT`, values written into a fixed pattern (`A.coef`) | every phase iteration |
| `vphD` (lumped reaction diagonal) | $D=A\mathbf 1$ (the stiffness rows sum to zero) | every phase iteration |
| `vphB` (Newton right-hand side) | $b=A\phi_k-R$ | every phase iteration |
| `vphL` (lumped mass) | built once | — |
| `vph2`, `vgph` (element means of φ², g(φ)) | `k2dPhElem` | every tangent refresh |
| `vDph` (phase dissipation) | `k2dPhElem` | every step |
| `vCurlFp` (GND curl) | two constant P0 → P1 operators | every step |
| `vTr` (heat right-hand side) | $(\rho C/\Delta t)MT_n+B_{01}D/\Delta t$ | every step |

Phase field on the production mesh, serial, 10 steps (48 active-set iterations): 57.2 s → 11.5 s with the same LU solve, 2.6 s with the
projected CG below. Coarse mesh, whole step: the work after the Newton solve falls from 0.53 to 0.28 s per step; the step itself (8.5 s
serial) is dominated by the mechanical linear solve.

**How the fast assembly works.** Nothing about the matrices changes; what changes is who builds them and how often.
1. *Built once per run:* the sparsity pattern of each matrix (taken from one FreeFEM assembly), the map from every element entry to its
   position in the matrix's coefficient array, the element areas and basis gradients, and the quadrature rule (the same 7-point rule
   `qf5pT` that `int2d` uses by default; the 3 edge midpoints for the mechanics). Linear forms with constant coefficients (GND curl, heat
   right-hand side) become constant matrices.
2. *Every call:* one compiled loop over the elements evaluates the fields at the quadrature points once, computes the element matrix and
   residual together, and adds them into the coefficient array (`v[pos] += value`); the FreeFEM matrix receives the values in place
   (`A.coef = v`). No expression is interpreted, no matrix is allocated or sorted, and quantities shared by several forms (φ, T and the
   Arrhenius factor at the quadrature points) are computed once.
3. *Algebra instead of forms:* the active-set diagonal is $A\mathbf 1$ and the Newton right-hand side is $A\phi_k-R$.

The speed-up comes from (2) and (3); the matrices are the FreeFEM ones to round-off, which the periodic comparison verifies.

**Switch.** Fast assembly is on by default (`-fastasm 1`; v2 `-asm 1`). `FASTASM=0` (run.sh), i.e. `-asm 0 -fastasm 0`, assembles every
matrix and vector of the step by the FreeFEM forms again: the phase matrix, residual, diagonal and right-hand side by `vphA`, `vphR`, `vphD`,
`vphB`, the element means, dissipation, GND curl and heat right-hand side by their forms, and the mechanics tangent by the form assembly.
Use it after changing a form until the plugin kernels have been changed to match (the coarse test gives the same log to the printed digits
in both modes; 6.5 against 8.9 s per step serially). The projected-CG phase solve does not depend on it (`-phsolver`).

**Not plug and play.** The fast assembly is written for this discretisation and this model, and the check stops the run when they no
longer match, but it does not adapt. Changes that need code changes in the plugin (and, for the mechanics, in `make_v2.py`):
- *another finite-element space or quadrature:* the kernels hard-code P1 φ and T with the 7-point rule, P2 displacement / P1 θ with the
  edge-midpoint rule, and P0 internal variables; P2 φ, another rule or another element type means new kernels;
- *another material model or energy:* the element formulas (KWC coupling $g(\phi)$, Arrhenius viscosity, stored energy, elastic energy,
  slip law) are duplicated in C++; a change in the `.edp` forms must be made in `plugin/kwc2d.cpp` too (`-fastcheck`, `-adcheck` and
  `ASMCHECK` detect a mismatch, they do not fix it);
- *another mesh:* any triangular mesh is read at start-up and the pattern is rebuilt then, but adaptive remeshing during a run, or a
  restart on a different mesh, needs the set-up to be redone (the plugin keeps one pattern per process);
- *another boundary-condition layout or extra fields:* the patterns and the operators are built for the current dof layout.

## 6.13 Phase-field linear solve: projected CG (`-phsolver cg`, default; MPI `-petscph`)

Each active-set iteration eliminates the active nodes: the system handed to the solver is the free block of $A$ with lumped identity rows on
the active nodes, symmetric positive definite (after Jacobi scaling its spectrum lies in $[0.50, 2.00]$ on the production mesh). It is solved
by conjugate gradients with the Jacobi preconditioner (serial: `LinearCG`; MPI: `-petscph`, default
`-ksp_type cg -ksp_rtol 1e-13 -ksp_max_it 2000 -pc_type jacobi`). For bounds that act on single nodes this is the projected preconditioned CG
with the constraint preconditioner $\begin{pmatrix}\operatorname{diag}A&E^T\\E&0\end{pmatrix}$ of the KKT system with explicit multipliers
$\lambda_{lo}$, $\lambda_{hi}$ (Gould, Hribar and Nocedal 2001): the same iterates. The multipliers, if wanted, are $A\phi-b$ on the active
nodes. Comparison on the production mesh (10 phase steps, Python port matching the solver to $1.3\times10^{-11}$; total / linear-solve
seconds; production bounds, and a stress test with bounds $[0.3, 0.95]$ that makes up to all nodes active):

| Method | $[0, 1-10^{-7}]$ | $[0.3, 0.95]$ |
|---|---|---|
| elimination + CG/Jacobi (= projected CG; adopted) | 1.48 / 0.36 | 1.29 / 0.16 |
| KKT ($\lambda_{lo}$, $\lambda_{hi}$) + projected CG | 1.68 / 0.54 | 1.80 / 0.64 |
| KKT + augmented-Lagrangian Uzawa | 1.49 / 0.41 | 2.41 / 1.28 |
| KKT + MINRES, block-diagonal preconditioner | 1.52 / 0.37 | 2.95 / 1.72 |
| KKT + sparse LU | 9.65 / 8.33 | 5.88 / 4.55 |
| KKT + LDLᵀ (QDLDL) | 6.77 / 5.53 | 10.21 / 8.97 |
| elimination + sparse LU (previous serial solve) | 9.68 / 8.37 | 2.09 / 0.85 |

All reach the same φ (to $5\times10^{-11}$) and the KKT conditions to $2\times10^{-9}$ or better, with non-negative multipliers.
Safeguards: a serial CG solve that does not converge in 2000 iterations is redone by the sparse direct solver (counted); a phase step that
does not converge with CG (in MPI the KSP does not stop the run, the active-set KKT test catches it) is repeated once from $\phi_n$ with
the previous solver (serial direct; MPI `-petscp1`), counted, before the usual stop. Both counts are printed at the end of the run. Tested
serially (coarse mesh, and with CG capped at one iteration to exercise the fallback); the MPI path is generated, not yet run.


**Check (`-fastcheck` N, default 50; `-fastchecktol` 10⁻⁸).** Each fast assembly is compared with its form on its first call, every N-th
call, and (phase matrix) on the first call in which the Arrhenius floor is reached anywhere and the first in which a node sits on a bound of
φ. The comparison is row by row (element by element for the means), relative to the size of the terms of the row: a global max norm would
hide a wrong entry in an ordinary row behind the rows with $g''\sim10^{14}$ near φ = 1, or behind the terms that cancel in the curl. The
dissipation is compared with its largest value. Round-off: at most 2×10⁻¹² on the coarse test; the tolerance allows for $g''$ amplifying the
round-off of $1-\phi$ by up to $10^7$. A 1% error in one entry of the phase matrix stops the run (measured 1.1×10⁻³); a difference above the
tolerance writes `<out>_FASTCHECK.txt` and stops. The end of the run prints the number of comparisons and the largest difference.

