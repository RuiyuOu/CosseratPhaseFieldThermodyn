#!/usr/bin/env python3
# apply_r8.py -- version 7.2 changes (fast assembly of the staggered fields + projected-CG phase solve) applied IN PLACE to a repository
# tree of any later version (7.2 ... 7.4), without overwriting other files. Every edit point is checked first; if one is missing nothing is
# written. Backups: <file>.pre_r8.  Usage (repository root):  python3 apply_r8.py [repo_dir]
import os, sys, shutil, textwrap
here = os.path.dirname(os.path.abspath(__file__)); root = sys.argv[1] if len(sys.argv) > 1 else "."
P = lambda f: os.path.join(root, f)
files = {f: open(P(f)).read() for f in ["cosserat_kwc.edp", "mpi/make_mpi.py", "run.sh", "plugin/kwc2d.cpp"]}
new = dict(files); problems = []
# 1) solver: the patch script (exact-text, asserts on every target)
if "k2dPhAsm" in files["cosserat_kwc.edp"]: problems.append("cosserat_kwc.edp is already patched")
else:
    import tempfile, subprocess
    t = tempfile.NamedTemporaryFile("w", suffix=".edp", delete=False); t.write(files["cosserat_kwc.edp"]); t.close()
    r = subprocess.run([sys.executable, os.path.join(here, "patch_fastasm_r8.py"), t.name], capture_output=True, text=True)
    if r.returncode: problems.append("cosserat_kwc.edp: " + (r.stderr.strip().splitlines() or ["?"])[-1])
    else: new["cosserat_kwc.edp"] = open(t.name).read()
    os.unlink(t.name)
# 2) MPI generator
m = files["mpi/make_mpi.py"]
a1 = '''    'string p1Opt = arg("-petscp1", "-ksp_type gmres -ksp_rtol 1e-13 -ksp_max_it 2000 -pc_type asm -sub_pc_type lu");\\n')'''
a2 = '''rep("        set(Am, solver = sparsesolver);\\n        phi[] = Am^-1*bph;\\n", """        Ap1 = Am; set(Ap1, sparams = pfx(p1Opt, "ph_"), prefix = "ph_");
        phi[] = Ap1^-1*bph;
""")'''
if "phOpt" in m: problems.append("mpi/make_mpi.py is already patched")
elif m.count(a1) != 1 or m.count(a2) != 1: problems.append("mpi/make_mpi.py: the -petscp1 line or the phase-solve patch is not where 7.1 had it (merge by hand: see the r8 diff)")
else:
    m = m.replace(a1, a1[:-1] + '''
    + 'string phOpt = arg("-petscph", "-ksp_type cg -ksp_rtol 1e-13 -ksp_max_it 2000 -pc_type jacobi");   // r8b: phase field (SPD eliminated system)\\n')''')
    m = m.replace(a2, '''if "phCGnow" in s:   # r8b: projected CG (-petscph, default CG + Jacobi); the repeat of a failed step uses -petscp1
    rep("""        if (phCGnow) { phDinv = Am.diag; phDinv = phOne ./ phDinv; real[int] x0 = phi[];
          int itcg = phPCG(Am, x0, bph);
          if (itcg >= 0) { phi[] = x0; nPhCGit += itcg; } else { nPhCGfail++; set(Am, solver = sparsesolver); x0 = Am^-1*bph; phi[] = x0; } }
        else {
        set(Am, solver = sparsesolver);
        phi[] = Am^-1*bph;
        }
""", """        Ap1 = Am;
        if (phCGnow) set(Ap1, sparams = pfx(phOpt, "ph_"), prefix = "ph_"); else set(Ap1, sparams = pfx(p1Opt, "phf_"), prefix = "phf_");
        phi[] = Ap1^-1*bph;
""")
else:
''' + ("    " + a2))
    new["mpi/make_mpi.py"] = m
# 3) run.sh: pass PETSCPH
r = files["run.sh"]; a3 = '[ -n "${PETSCP1:-}" ] && PARGS+=(-petscp1 "$PETSCP1")'
if "PETSCPH" in r: problems.append("run.sh is already patched")
elif r.count(a3) != 1: problems.append("run.sh: the PETSCP1 line is not where 7.1 had it")
else: new["run.sh"] = r.replace(a3, a3 + '; [ -n "${PETSCPH:-}" ] && PARGS+=(-petscph "$PETSCPH")')
# 4) plugin: phase kernels + registration
c = files["plugin/kwc2d.cpp"]; blk = open(os.path.join(here, "r8_plugin_block.cpp")).read()
if "k2dPhAsm" in c: problems.append("plugin/kwc2d.cpp is already patched")
elif c.count("static void Load_Init() {") != 1 or c.count('  Global.Add("k2dThreads"') != 1: problems.append("plugin/kwc2d.cpp: Load_Init / k2dThreads registration not found once")
else:
    c = c.replace("static void Load_Init() {", blk + "static void Load_Init() {")
    c = c.replace('  Global.Add("k2dThreads"', '''  Global.Add("k2dPhSetup", "(", new OneOperator4_<double, KNM<long>*, KNM<double>*, KN<long>*, KN<long>*>(k2dPhSetup));
  Global.Add("k2dPhAsm", "(", new OneOperator5_<double, KNM<double>*, KNM<double>*, KN<double>*, KN<double>*, KN<double>*>(k2dPhAsm));
  Global.Add("k2dPhElem", "(", new OneOperator3_<double, KNM<double>*, KN<double>*, KNM<double>*>(k2dPhElem));
  Global.Add("k2dThreads"''')
    new["plugin/kwc2d.cpp"] = c
if problems:
    print("NOT APPLIED (nothing written):"); [print("  -", p) for p in problems]; sys.exit(1)
for f, txt in new.items():
    shutil.copy2(P(f), P(f) + ".pre_r8"); open(P(f), "w").write(txt)
shutil.copy2(os.path.join(here, "patch_fastasm_r8.py"), P("patch_fastasm_r8.py"))
print("applied to", root, "(backups *.pre_r8). Next: bash plugin/build_plugin.sh  (rebuilds kwc2d.so, regenerates the v2 and MPI solvers)")
