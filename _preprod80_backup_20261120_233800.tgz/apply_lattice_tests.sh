#!/bin/bash
# apply_lattice_tests.sh -- adds the lattice-frame tests (stress and slip follow the lattice) to the repository.
# Run in the repository root after 'unzip -o lattice_frame_tests.zip'. Safe to run again. No solver file is changed.
#   checks/lattice_frame_common.py, checks/test_stress_follows_lattice.py, checks/test_slip_follows_lattice.py,
#   checks/LATTICE_FRAME_TESTS.md, checks/lattice_frame_proof.{md,tex,pdf}, checks/lattice_frame_figs/
set -euo pipefail
cd "$(dirname "$0")"
[ -s README.md ] && [ -d checks ] || { echo "not the repository root (README.md or checks/ missing)"; exit 1; }
for f in checks/lattice_frame_common.py checks/test_stress_follows_lattice.py checks/test_slip_follows_lattice.py checks/LATTICE_FRAME_TESTS.md; do
  [ -s "$f" ] || { echo "missing $f (unzip the bundle in the repository root first)"; exit 1; }
done
chmod +x checks/test_stress_follows_lattice.py checks/test_slip_follows_lattice.py
python3 - <<'PYEOF'
import re
def edit(path, anchor_re, new, mark, where="after"):
    try: s = open(path).read()
    except FileNotFoundError: print(f"{path}: not found, skipped"); return
    if mark in s: print(f"{path}: already has the lattice-frame entry"); return
    m = re.search(anchor_re, s, re.M)
    if not m: print(f"{path}: anchor not found, add by hand:\n{new}"); return
    i = m.end() if where == "after" else m.start()
    s = s[:i] + new + s[i:]; open(path, "w").write(s); print(f"patched {path}")
row = ("| `checks/test_stress_follows_lattice.py`, `checks/test_slip_follows_lattice.py` | Pointwise tests that the stress and the "
       "slip systems follow the current lattice although C, s_a, n_a are rotated once (see `checks/LATTICE_FRAME_TESTS.md`). | "
       "`python3 checks/test_stress_follows_lattice.py`; `python3 checks/test_slip_follows_lattice.py` |\n")
edit("README.md", r"^\| `checks/compare_runs.py` \|.*\n", row, "| `checks/test_stress_follows_lattice.py`")
para = ("\n`python3 checks/test_stress_follows_lattice.py` and `python3 checks/test_slip_follows_lattice.py` (numpy only, seconds) check "
        "that the stress tau = P F^T and the resolved shear stresses follow the current lattice R_t = R R0 for rigid rotation, slip, "
        "grain-boundary spin and the time-stepped spin update, with C and the slip systems rotated once at setup; rotating them again "
        "must fail (it gives a crystal at twice the angle). Both elastic laws (`--law svk|prod`); exit 1 on failure. Details and expected "
        "output: `checks/LATTICE_FRAME_TESTS.md`; proof: `checks/lattice_frame_proof.pdf`.\n")
edit("README.md", r"^`checks/probe_mumps.edp` test a FreeFem module's MPI/PETSc and MUMPS\.\n", para, "(numpy only, seconds) check")
bul = ("- `test_stress_follows_lattice.py`, `test_slip_follows_lattice.py`, `lattice_frame_common.py`: pointwise lattice-frame tests "
       "(stress and slip systems follow R_t = R R0 with C, s_a, n_a rotated once; wrong double rotation must fail); "
       "`LATTICE_FRAME_TESTS.md`, `lattice_frame_proof.pdf`.\n")
edit("CODE_MAP.md", r"^- `compare_runs.py`: .*\n", bul, "test_stress_follows_lattice.py")
PYEOF
if [ -f .gitignore ]; then grep -qx 'checks/out/' .gitignore || { echo 'checks/out/' >> .gitignore; echo "added checks/out/ to .gitignore"; }; fi
echo "running the tests:"
python3 checks/test_stress_follows_lattice.py --no-fig | tail -1
python3 checks/test_slip_follows_lattice.py --no-fig | tail -1
