#!/bin/bash
# apply_v2.sh -- run in the repository root after every `unzip -o v2_production.zip` (safe to repeat).
# Removes the files of the former experimental set-up (the generator moved to v2/; run folders out_*_exp are NOT touched),
# then builds the plugin and generates cosserat_kwc_v2*.edp.
set -e
cd "$(dirname "${BASH_SOURCE[0]}")"
[ -f v2/make_v2.py ] && [ -f cosserat_kwc.edp ] || { echo "run this in the repository root after unzipping"; exit 1; }
rm -rf exp
rm -f cosserat_kwc_exp.edp cosserat_kwc_exp_mpi.edp
# generated files and the plugin binary: rebuilt unconditionally (unzip keeps the archive's file times, which can make a stale
# generated file look newer than its new source)
rm -f cosserat_kwc_mpi.edp cosserat_kwc_v2.edp cosserat_kwc_v2_mpi.edp kwc2d.so mpi/kwc2d.so
bash plugin/build_plugin.sh
echo "both set-ups run the v2 solver; OLD=1 = rotational inertia j = 0.01, otherwise identical (cosserat_kwc_production.md, Section 15)"
