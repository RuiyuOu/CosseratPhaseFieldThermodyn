
#!/usr/bin/env python3

# apply_storecap.py -- counter for the Clausius-Duhem storage cap (in place; backup cosserat_kwc.edp.pre_storecap)

import sys, shutil

f = sys.argv[1] if len(sys.argv) > 1 else "cosserat_kwc.edp"; s = open(f).read(); bad = []

if "nStoreCap" in s: print("already has the storage-cap counter"); sys.exit(0)

# 1) declarations, after the line that declares the SSD-floor counters

lines = s.split("\n"); k = [i for i, l in enumerate(lines) if "EfloorCum = 0;" in l and l.lstrip().startswith(("real", "int"))]

if len(k) != 1: bad.append("declaration line with 'EfloorCum = 0;' found %d times" % len(k))

else:

    lines.insert(k[0] + 1, "int nStoreCapEl = 0, nStoreCapSteps = 0; real EstoreCapCum = 0;   // Clausius-Duhem storage cap: binding element-steps, steps, withheld stored energy")

    s = "\n".join(lines)

# 2) count and log where the cap binds (all reductions on every rank; only the file write is on the root)

a2 = "    drho -= excess; dStore -= excess;\n"

if s.count(a2) != 1: bad.append("'drho -= excess; dStore -= excess;' found %d times" % s.count(a2))

else:

    s = s.replace(a2, a2 + '''    // count where the cap binds; one line per binding step in <out>_storecap.csv (step, t, elements, stored energy withheld Z*excess*area)

    real[int] flc(nt); for [i, v : excess] flc[i] = (v > 0) ? 1. : 0.;

    real nce = gsumEs(flc);

    if (nce > 0) {

      nStoreCapEl += lrint(nce); nStoreCapSteps++;

      tmp = excess .* Zst; tmp = tmp .* areas; real ecap = gsumEs(tmp); EstoreCapCum += ecap;

      if (isRoot()) {

        bool scHdr = (exec("test -s " + out + "_storecap.csv") != 0);

        ofstream fsc(out + "_storecap.csv", append);

        if (scHdr) fsc << "step,t_ns,elements_capped,stored_energy_withheld" << endl;

        fsc << n << "," << t << "," << lrint(nce) << "," << ecap << endl;

      }

    }

''')

# 3) end-of-run safeguard line

a3 = ' << ", W_plate " << Wplate << endl;'

add = ' << ", storage-cap steps " << nStoreCapSteps << " (elements " << nStoreCapEl << ", stored energy withheld " << EstoreCapCum << ")"'

sl = [l for l in s.split("\n") if l.startswith('cout << "safeguard counters:')]

if len(sl) != 1: bad.append("safeguard-counters line found %d times" % len(sl))

elif a3 in sl[0]: s = s.replace(sl[0], sl[0].replace(a3, add + a3))

elif sl[0].rstrip().endswith("<< endl;"): s = s.replace(sl[0], sl[0].rstrip()[:-len("<< endl;")].rstrip() + add + " << endl;")

else: bad.append("safeguard-counters line has an unexpected ending")

if bad: print("NOT APPLIED (nothing written):"); [print("  -", b) for b in bad]; sys.exit(1)

shutil.copy2(f, f + ".pre_storecap"); open(f, "w").write(s); print("applied (backup %s.pre_storecap). Next: bash plugin/build_plugin.sh" % f)

